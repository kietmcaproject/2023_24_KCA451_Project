<?php
$config['sold_as'] = array ('Kg','Pisces','Ton','Unit');
$config['tax_rate'] = array ('5','12','18','28');
 ?>
