<?php
$config['sold_as'] = array ('Kg','Pisces','Ton','Unit');
$config['tax_rate'] = array ('1','2','3','4','5','12','18','28');
 ?>
