import React, { useState ,useEffect} from 'react';
import { Link, useHistory } from 'react-router-dom';
import './styles.css';
import toast from 'react-hot-toast';

function Login() {
    const history = useHistory();
    
    // State to hold username and password input values
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    // Function to handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Send POST request to login API route
            const response = await fetch('http://localhost:5000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email: username, password }), // Assuming email is used for login
            });

            if (!response.ok) {
                const errorMessage = await response.text();
                throw new Error(errorMessage || 'Login failed');
            }

            // Reset the form after successful login
            setUsername('');
            setPassword('');
            setError('');

            // Save user information to localStorage
            const userData = await response.json();
            localStorage.setItem('email', username);
            console.log('User data saved to localStorage:', userData);

            // Redirect to home page after successful login
            history.push("/");
        } catch (error) {
            console.error('Login error:', error);
            toast.error("Error in Login")
            setError(error.message || 'Login failed');
        }
    };

    useEffect(() => {
        // Check if email exists in localStorage
        const email = localStorage.getItem('email');
        if (email) {
            // Redirect to home page if email exists
            history.push("/");
        }
    }, []);

    return (
        <div className="login-container">
            <h2>Login</h2>
           
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="username">Username:</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <div style={{ padding: '10px' }}>
                    If not registered,{' '}
                    <Link to="/signup">Click Here</Link> to sign up
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    );
}

export default Login;
