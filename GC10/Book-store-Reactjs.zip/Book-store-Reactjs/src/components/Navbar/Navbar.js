import React from "react";
import {
  AppBar,
  Toolbar,
  IconButton,
  Badge,
  Typography,
} from "@material-ui/core";
import { ShoppingCart, AccountCircle } from "@material-ui/icons"; // Import AccountCircle icon
import { Link } from "react-router-dom";
import logo from "../../assets/circles.png";
import useStyles from "./styles";

const Navbar = ({ totalItems }) => {
  const classes = useStyles();
  const handleLogout = () => {
    localStorage.removeItem('email');
    window.location.href = "/login";
  };

  // Check if email is present in localStorage
  const email = localStorage.getItem('email');

  return (
    <div>
      <AppBar position="fixed" className={classes.appBar} color="inherit">
        <Toolbar>
          <Typography
            component={Link}
            to="/"
            variant="h5"
            className={classes.title}
            color="inherit"
          >
            <img
              src={logo}
              alt="Book Store App"
              height="50px"
              className={classes.image}
            />
            <div>BookStore & Library</div>
          </Typography>

          <div className={classes.grow} />
          <div className={classes.button}>
            {email ? (
              // If email is present in localStorage, render logout link
              <Typography variant="h6" color="inherit" component={Link} to="/login" onClick={handleLogout}>
                Logout
              </Typography>
            ) : (
              // If email is not present in localStorage, render login link
              <Typography
                variant="h6"
                color="inherit"
                component={Link}
                to="/login" // Link to the login route
              >
                Login
              </Typography>
            )}

            <IconButton
              component={Link}
              to="/cart"
              aria-label="Show cart items"
              color="inherit"
            >
              <Badge badgeContent={totalItems} color="secondary">
                <ShoppingCart />
              </Badge>
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
    </div>
  );
};

export default Navbar;
