-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: envsurvey
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `e_addsurveybyfaculty`
--

DROP TABLE IF EXISTS `e_addsurveybyfaculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_addsurveybyfaculty` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(145) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `venue` varchar(145) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_addsurveybyfaculty`
--

LOCK TABLES `e_addsurveybyfaculty` WRITE;
/*!40000 ALTER TABLE `e_addsurveybyfaculty` DISABLE KEYS */;
INSERT INTO `e_addsurveybyfaculty` VALUES (3,'Covid ','Awareness for Covid','8','11/20/2020','NMU college');
/*!40000 ALTER TABLE `e_addsurveybyfaculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_comp`
--

DROP TABLE IF EXISTS `e_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_comp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(245) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_comp`
--

LOCK TABLES `e_comp` WRITE;
/*!40000 ALTER TABLE `e_comp` DISABLE KEYS */;
INSERT INTO `e_comp` VALUES (1,'Poster Competiton','Aware for Air Pollution','1','12/02/2020','MJ college'),(2,'Drawing Competition','Draw Drawing of Air Pollution ','1','12/14/2020','University of Nairobi');
/*!40000 ALTER TABLE `e_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_compbyfaculty`
--

DROP TABLE IF EXISTS `e_compbyfaculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_compbyfaculty` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(245) NOT NULL,
  `volunteer` int NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_compbyfaculty`
--

LOCK TABLES `e_compbyfaculty` WRITE;
/*!40000 ALTER TABLE `e_compbyfaculty` DISABLE KEYS */;
INSERT INTO `e_compbyfaculty` VALUES (1,'Essay','Awareness for Covid',2,'11/07/2020','MJ college'),(2,'Essay Seminar','Awareness for Covid',8,'11/13/2020','MJ college');
/*!40000 ALTER TABLE `e_compbyfaculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_faq`
--

DROP TABLE IF EXISTS `e_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_faq` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` varchar(4500) NOT NULL,
  `answer` varchar(4500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_faq`
--

LOCK TABLES `e_faq` WRITE;
/*!40000 ALTER TABLE `e_faq` DISABLE KEYS */;
INSERT INTO `e_faq` VALUES (1,'How to register for the survey?','Go to not registered yet? link and register.'),(2,'How to participate in the survey?','Register for the survey'),(3,'How will I be intimated with the new survey?','on home screen'),(4,'What if it gives error, after participating in the entire survey, and clicked on the submit button at the last for submitting the survey?','write to support team'),(5,'Why I am unable to participate in the survey? (Two reasons : 1.Not the registered user, and 2.Technical Problem)','any of the two problem');
/*!40000 ALTER TABLE `e_faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_paticipation`
--

DROP TABLE IF EXISTS `e_paticipation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_paticipation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `venue` varchar(45) DEFAULT NULL,
  `volunteers` varchar(20) DEFAULT NULL,
  `dateofseminar` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_paticipation`
--

LOCK TABLES `e_paticipation` WRITE;
/*!40000 ALTER TABLE `e_paticipation` DISABLE KEYS */;
INSERT INTO `e_paticipation` VALUES (1,'Essay Seminar','University of Nairobi','2','11/06/2020'),(3,'Poster Seminar','Egerton University','1','11/05/2020');
/*!40000 ALTER TABLE `e_paticipation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_submitted`
--

DROP TABLE IF EXISTS `e_submitted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_submitted` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `totalsurvey` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_submitted`
--

LOCK TABLES `e_submitted` WRITE;
/*!40000 ALTER TABLE `e_submitted` DISABLE KEYS */;
INSERT INTO `e_submitted` VALUES (1,'abc',1),(2,'abc',1),(3,'abc',1);
/*!40000 ALTER TABLE `e_submitted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_support`
--

DROP TABLE IF EXISTS `e_support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_support` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `subject` varchar(245) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_support`
--

LOCK TABLES `e_support` WRITE;
/*!40000 ALTER TABLE `e_support` DISABLE KEYS */;
INSERT INTO `e_support` VALUES (1,'huma','khan','student','site not working'),(2,'uzema','khan','student','technical issue'),(3,'naushin','khan','student','trouble login');
/*!40000 ALTER TABLE `e_support` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_surveyfaculty`
--

DROP TABLE IF EXISTS `e_surveyfaculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_surveyfaculty` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `volunteer` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  `venue` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_surveyfaculty`
--

LOCK TABLES `e_surveyfaculty` WRITE;
/*!40000 ALTER TABLE `e_surveyfaculty` DISABLE KEYS */;
INSERT INTO `e_surveyfaculty` VALUES (4,'Soil pollution','Awareness of Soil Pollution','8','11/24/2020','JKUAT');
/*!40000 ALTER TABLE `e_surveyfaculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_surveystudent`
--

DROP TABLE IF EXISTS `e_surveystudent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_surveystudent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(145) NOT NULL,
  `volunteer` varchar(25) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `venue` varchar(145) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_surveystudent`
--

LOCK TABLES `e_surveystudent` WRITE;
/*!40000 ALTER TABLE `e_surveystudent` DISABLE KEYS */;
INSERT INTO `e_surveystudent` VALUES (1,'Pollution','Air Pollution causes','8','11/28/2020','JKUAT');
/*!40000 ALTER TABLE `e_surveystudent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `e_user`
--

DROP TABLE IF EXISTS `e_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `e_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `roll_no` varchar(25) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `specification` varchar(45) DEFAULT NULL,
  `section` varchar(45) DEFAULT NULL,
  `roleid` bigint DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `dateofadmission` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_user`
--

LOCK TABLES `e_user` WRITE;
/*!40000 ALTER TABLE `e_user` DISABLE KEYS */;
INSERT INTO `e_user` VALUES (30,'abc','1','FE','abcd','A',3,'abc',1,'01/05/2018'),(34,'admin','100','se','cse','B',1,'admin123',NULL,'10/02/1994'),(37,'Sheeba','31','SE','Biotech','A',3,'khan',1,'02/03/2017'),(39,'Shirin','12','BE','PHD','A',2,'shirin@123',NULL,'01/05/2017'),(41,'Naushin','2','BE','Biology','C',3,'khan',1,'05/02/2018');
/*!40000 ALTER TABLE `e_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-29 11:29:41
