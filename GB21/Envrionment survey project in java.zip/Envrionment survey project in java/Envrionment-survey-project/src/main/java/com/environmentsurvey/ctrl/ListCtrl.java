package com.environmentsurvey.ctrl;

public interface ListCtrl {
		public String APP_CONTEXT="/Envrionment-survey-project";
		public String login=APP_CONTEXT+"/login.jsp";
}
