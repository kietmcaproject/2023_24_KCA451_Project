from django.contrib import admin
from directs.models import Message

admin.site.register(Message)
