from django.apps import AppConfig


class DirectsConfig(AppConfig):
    name = 'directs'
