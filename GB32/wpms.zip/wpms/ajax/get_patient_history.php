<?php 
	include '../config/connection.php';

  	$patientId = $_GET['patient_id'];
    
    $data = '';
    /**
    medicines (medicine_name)
    medicine_details (packing)
    patient_visits (visit_date, disease,weight,bp)
    patient_medication_history (quantity, dosage)
    reports(report)

    */
    $query = "SELECT distinct `m`.`medicine_name`, `md`.`packing`, 
    `pv`.`visit_date`, `pv`.`disease`, `pv`.`weight`,`pv`.`bp`,`pv`.`temp`,`pv`.`pr`,`pv`.`complaint`,`pv`.`med`
    from `medicines` as `m`, `medicine_details` as `md`, `reports` as `r`,
    `patient_visits` as `pv` 
    where `m`.`id` = `md`.`medicine_id` and 
    `pv`.`patient_id` = $patientId and
    `m`.`id` = `pv`.`dr_id`;
    order by `pv`.`id` asc;";

    try {
      $stmt = $con->prepare($query);
      $stmt->execute();
      // echo $patientId;
      $i = 0;
      while($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $i++;
       
        $data = $data.'<tr>';
        
        $data = $data.'<td class="px-2 py-1 align-middle text-center">'.$i.'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle">'.date("M d, Y", strtotime($r['visit_date'])).'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle">'.$r['disease'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle">'.$r['medicine_name'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['packing'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['bp'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['weight'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['temp'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['pr'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['complaint'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$r['med'].'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right">'.$patientId.'</td>';
        

       
      }

    } catch(PDOException $ex) {
      echo $ex->getTraceAsString();
      echo $ex->getMessage();
      exit;
    }

  	echo $data;
?>
