
<?php
include('common/connection.php');


$id = $_REQUEST['id'];
  		$status = 'verified';
        $sql="UPDATE clientlogin SET c_status='$status' WHERE c_id = '$id'";

        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'verifyuser.php';
    </script>";
        }
        mysqli_close($conn);

?>