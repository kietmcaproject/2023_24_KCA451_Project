<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$pswrd = $_POST['pswrd'];
        $idd=$_SESSION['id'];

        $sql="UPDATE clientlogin SET password='".$pswrd." WHERE id = ".$idd."";

       // / print_r($sql); die();

        if(mysqli_query($conn,$sql)){
        	echo "<script>
      window.location.href = 'logins.php';
      alert('Reset password successfully...');
      </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>
