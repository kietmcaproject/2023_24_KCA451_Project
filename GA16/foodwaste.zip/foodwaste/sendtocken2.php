<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include_once('common/connection.php');

include_once('sendmail.php');


if(isset($_REQUEST['email']))
{
$email =mysqli_real_escape_string($conn,$_POST['email']);
$ranpass =rand(10000,999999);

$check_email = "SELECT * from organisations where email='$email' LIMIT 1";
$check_email_run = mysqli_query($conn,$check_email);

if(mysqli_num_rows($check_email_run)>0)
{
$row=mysqli_fetch_array($check_email_run);
$get_name = $row['name'];
$get_email = $row['email'];
$update_pass = "UPDATE organisations set password='$ranpass' where email='$get_email'";
$update_pass_run = mysqli_query($conn,$update_pass);

if($update_pass_run)
{
$html = "Hii, $get_name<br/> Your new password is {$ranpass},<br/>you can change your password https://localhost/antipesto/logins.php";
sendmail($get_email,$get_name,$html,'Forgot Password');
$_SESSION['status']= "we emailed you a password reset link";
header("location: logins.php");
exit(0);
}
else{
$_SESSION['status'] = "something went wrong!";
 header("location: forget2.php");
exit(0);
}
}
else{
$_SESSION['status'] = "NO Email found";
 header("location: forgetq2.php");
exit(0);
}
}
?>