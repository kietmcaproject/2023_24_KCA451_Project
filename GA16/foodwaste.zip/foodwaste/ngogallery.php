<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:logins.php');
}
 ?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>ANTI PESTO</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
 
 select{
    width: 200%;
    margin: 10px 0;
    border-color: greenyellow;
    border-radius: 5px;
    padding: 7px 10px 7px 0px;
    font-size: 18px; 
    box-sizing: border-box;
    cursor: pointer;
  }
  .navbar-b{
    margin-top: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .dropdown{
    margin-left: 10%;
    background-color: white;
    border-radius: 3px;  
  }
  main{
    padding-top: 20px;
    max-width: 1500px;
    width: 95%;
    margin: 30px auto;
    display: flex;
    flex-wrap: wrap;
    margin: auto;
    margin-bottom: 15px;
  }
  main .card{
    max-width: 250px;
    flex: 1 1 210px;
    text-align: center;
    height: 570px;
    border: 1px solid lightgray;
    margin: 20px;
  }
  main .card .image{
    height: 60%;
    margin-bottom: 20px;
  }
  main .card .image img{
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  main .card .caption{
    padding-left: 1em;
    text-align: left;
    line-height: 3em;
  }
  main .card .caption p{
    font-size: 1em;
  }
  main .card .caption .rate{
    display: flex;
  }
  main .card .caption .rate i{
    color: gold;
    margin-left: 2px;
  }
  main .card a{
    width: 50%;
  }
  main .card a{
    margin-left: 10%;
    border: 2px solid black;
    padding: 0.8em;
    width: 80%;
    cursor: pointer;
    font-weight: bold;
    position: relative;
    margin-bottom:5%;
  }
  main .card button::before{
     content: "";
     position: absolute;
     top: 0;
     left: 0;
     bottom: 0;
     width: 0;
     background-color: yellowgreen;
     transition: all .5s;
     margin: 0; 
     
  }
  main .card button::after{
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    width: 0;
    background-color: yellowgreen;
    transition: all .5s;
  }
  main .card button:hover::before{
      width: 30%;
  }
  main .card button:hover::after{
      width: 30%;
  }
  .gallery .gallerycontainer{
    column-count: 4;
    column-gap: 20px;
    margin-bottom: 20px;
}
.gallery .gallerycontainer .item{
    position: relative;
    margin-bottom: 20px;
    overflow: hidden;
}
.gallery .gallerycontainer img{
    width: 100%;
    display: block;
    transition: 0.4s;
}
.gallery .gallerycontainer .title{
    position: absolute;
    background-color: var(--gray);
    padding: 5px;
    margin: 5px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: bold;
    opacity: 0;
    z-index: 1;
}
.gallery .gallerycontainer .item:hover .title{
    opacity: 1;
}
.gallery .gallerycontainer .item:hover img{
    transform: scale(1.2);
}
    </style>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
          <a href="https://www.google.com/maps/dir//Merrut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Merrut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
              <a class="" href="ngohome.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php">Donor Request</a>
              <a class="" href="ngoresetpassword.php">Reset Password</a>
              <a class="" href="ngogallery.php">Gallery</a>
              <a class="" href="ngocontact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="ngohome.php">
            <span>
              Zero Hunger
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
</div>
	    <section class="gallery" id="gallerysection">
          <div class="container">
			<div class="sectionTitle" style="font-size:40px; color:black; text-align:center; margin-bottom: 25px;">GALLERY</div>
            
      <div class="gallerycontainer">
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G1.png" alt="" />
                </div>
                <div class="item">
                    <span class="title"> </span>
                    <img  src="images/G2.jpeg" alt="" />
                </div>
                <div class="item">
                    <span class="title"> </span>
                    <img  src="images/G3.webp" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G4.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G5.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G6.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G7.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G8.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G9.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G10.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G11.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G12.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G13.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G14.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G15.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G16.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G17.png" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G18.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G19.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G20.webp" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G21.jpg" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G22.webp" alt="" />
                </div>
                <div class="item">
                    <span class="title">  </span>
                    <img  src="images/G23.png" alt="" />
                </div>
            </div>
		  </div>
		  </section>
 

  <!-- end why section -->


  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Merrut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="tel:9759000083">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +9759000083
                </span>
              </a>
              <a href="mailto:chaudharynavneet1234@gmail.com">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="ngohome.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Requests</a>
              <a class="" href="ngogallery.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a>
              <a class="" href="ngoresetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="ngocontact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
            Newsletter
          </h5>
          <form action="">
            <input type="text" placeholder="Enter Your email" />
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Navneet Chaudhary</a>  <a href="https://themewagon.com"></a>
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
 
</body>

</html>