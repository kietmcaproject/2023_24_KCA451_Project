<?php
include('common/mainheader.php');
?>
<style>
  <style>
@media screen and (max-width: 600px) {
  form{
    width: 25rem;
  }

}

@media screen and (max-width: 400px) {
  form{
    width: 20rem;
  }
}
body 
{
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  
}

h1{
    text-align: center;
}


.form-p{
    width:35rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
    margin-bottom:20px;
}
.select-p{
  font-size:30px;
}

input[type=file],input[type=text], input[type=name]{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 10px 18px;
    box-sizing: border-box;
  }
  select{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 15px 20px;
    box-sizing: border-box;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 5px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }

  /* Media queries for the responsiveness of the page */
  @media screen and (max-width: 600px) {
    form{
      width: 25rem;
    }
  }
  
  @media screen and (max-width: 400px) {
    form{
      width: 20rem;
    }
  }

  /* image logo */
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
.col-md-4{
  width:10px;
}
  </style>
</style>
    <form action="foundnewpest.php" method="post" enctype="multipart/form-data" style="margin-top: 30px;" class="form-p">
    <div class="imgcontainer">
    
    <img src="images/logo1.jpg" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Donate Money</h3>
            <p><?= $_SESSION['email'];?></p>
            <p>NOTE: Enter Your Details</p>
        </div>
        <div class="imgcontainer">
        <img src="images/img.JPG" alt="Avatar" class="avatar" width="400px" height="400px" style="border-radius: 50px;"><br><br>
        </div>
        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Password -->
            <label for="text">Your Email</label>
            <input value="<?= $_SESSION['email'];?>" type="text" placeholder="Enter Your Name" name="email" required>
            <label for="text">Name</label>
            <input value="<?= $_SESSION['name'];?>" type="text" placeholder="Enter Your Name" name="name" required>
            <label for="image">Payment Image</label>
            <input type="file" placeholder="upload image" required class="img" name="img">
            <label for="text">Transaction Date-Time</label><br>
            <input type="datetime-local" placeholder="Date" required class="date" name="date"><br><br>
            <label for="text">Your UPI ID</label>
            <input type="text" placeholder="Enter upi id" name="upi_id" required>
            <label for="text">UPI REF NO</label>
            <input type="text" placeholder="Enter Reference ID" name="reference" required>


            <!-- Submit button -->
            <button type="submit" name="submit">send</button>
            <p class="register">History-><a href="moneydonatehistory.php">Money Donation History</a></p>
            <p class="register">Go Back-><a href="donation.php">Donate</a></p>

        </div>

    </form>
    <?php
include('common/footer.php');
?>
    <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
  </body>
</html>