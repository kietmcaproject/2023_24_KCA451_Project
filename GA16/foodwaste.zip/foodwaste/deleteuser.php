<?php
include('common/connection.php');


$id = $_REQUEST['em'];

$sql="delete from clientlogin where c_email ='$id'";
mysqli_query($conn,$sql);
header("Location:verifyuser.php");
?>