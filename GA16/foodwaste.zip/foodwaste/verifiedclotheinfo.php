
<?php
include('common/connection.php');


$id = $_REQUEST['id'];
  		$status = 'verified';
        $sql="UPDATE clothedonate SET cl_status='$status' WHERE cl_id = '$id'";

        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'clotheverify.php';
    </script>";
        }
        mysqli_close($conn);

?>