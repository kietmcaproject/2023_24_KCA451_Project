<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:ngologin.php');
}
 ?>
<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Zero Hunger</title>

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
            <a href="https://www.google.com/maps/dir//Meerut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Meerut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
              <a class="" href="ngohome.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php">Donor Request</a>
              <a class="" href="ngoresetpassword.php">Reset Password</a>
              <a class="" href="ngogallery.php">Gallery</a>
              <a class="" href="ngocontact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="home.php">
            <span>
              Zero Hunger
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
            
            
          </div>
        </nav>
      </div>
    </header>
 

    <style>
@media screen and (max-width: 600px) {
  form{
    width: 25rem;
  }

}

@media screen and (max-width: 400px) {
  form{
    width: 20rem;
  }
}
body 
{
  font-family:sans-serif; 
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  
}

h1{
    text-align: center;
}


.form-c{
    width:35rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
    margin-bottom:50px;
}
 input[type=password]{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 15px 18px;
    box-sizing: border-box;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 5px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }

  /* Media queries for the responsiveness of the page */
  @media screen and (max-width: 600px) {
    form{
      width: 25rem;
    }
  }
  
  @media screen and (max-width: 400px) {
    form{
      width: 20rem;
    }
  }

  /* image logo */
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
  </style>
  
    <form action="updatepass2.php" method="post" style="margin-top: 30px;" class="form-c">
    <div class="imgcontainer">
    <img src="images/logo1.jpg" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Reset Password</h3>
            <p><?= $_SESSION['email'];?></p>
            <p>NOTE:Enter new password</p>
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Password -->
            <label for="pswrd">New password</label>
            <input type="password" placeholder="Enter New Password" name="pswrd" required>


            <!-- Submit button -->
            <button type="submit" name="submit">Reset</button>
            <p class="register">Go Back-><a href="ngohome.php">HOME</a></p>

        </div>

    </form>
    <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Meerut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location: Meerut,Uttar Pradesh(India)
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +91 9759000083
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="https://m.facebook.com/profile.php/?id=100009018195397">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="ngohome.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Requests</a>
              <a class="" href="ngogallery.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a>
              <a class="" href="ngoresetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="ngocontact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
          </h5>
          <form action="emailsend.php" method="post">
            <input type="text" name="email" placeholder="Enter Your email" required>
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Navneet Chaudhary</a>
    </p>
  </footer>
    <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
  </body>
</html>