<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $email = $_POST['email'];
        $bags = $_POST['bags'];
        $zila = $_POST['zila'];
        $address = $_POST['address'];
        $date = $_POST['date'];
         $status='Not verified';
          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;

        move_uploaded_file($tempname, $folder);
        $sql="insert into clothedonate(cl_name,cl_image,cl_email,cl_bags,cl_address,cl_status,cl_date,cl_zila) values('".$name."','$img','$email','$bags','$address','$status','$date','$zila')";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'clothedonationhistory.php';
          alert('your record inserted..');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>