<?php
include('common/connection.php');


$id = $_REQUEST['id'];
  		$status = 'Delivered';
        $sql="UPDATE clothedonate SET status='$status' WHERE id = '$id'";

        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'clothedonaterequest.php';
    </script>";
        }
        mysqli_close($conn);

?>