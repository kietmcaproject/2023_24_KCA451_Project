<section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Meerut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location: Meerut,Uttar Pradesh(India)
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +91 9759000083
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="https://m.facebook.com/profile.php/?id=100009018195397">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="home.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donation.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Donation</a>
              <a class="" href="history.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>History</a>
              <a class="" href="why.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a>
              <a class="" href="resetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="contact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
          </h5>
          <form action="emailsend.php" method="post">
            <input type="text" name="email" placeholder="Enter Your email" required>
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Navneet Chaudhary</a>
    </p>
  </footer>