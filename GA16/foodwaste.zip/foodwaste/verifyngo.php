
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
    width:15%;
  }
  select{
    width:8%;
  }
  button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  .container{
    margin-left:5%;
  }
  </style>
  <div class="fnt">
    <h1>Verify NGO</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value='' type="name" placeholder=" Registration Number" name="name" id="name">
      <input value='' type="address" placeholder=" zila" name="color" id="color">
      <input value='' type="text" placeholder=" Email" name="email" id="email">
      <input value='' type="tel" placeholder=" organisation" name="num" id="num" >
    </div>
    <div class="button-b">
        <button type="submit">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Registraion Number</th>
        <th>Organisation</th>
        <th>Email</th>
        <th>Head Name</th>
        <th>Gender</th>
        <th>Field</th>
        <th>Zila</th>
        <th>Address</th>
        <th>Number</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $email = filter_input(INPUT_POST,'email', FILTER_SANITIZE_STRING);
 $num = filter_input(INPUT_POST,'num', FILTER_SANITIZE_STRING);
 
 if($type=='')
 {
  $sql = "SELECT * FROM organisations where registration like '$name%' and o_zila like '$color%' and o_email like '$email%' and o_number like '$num%' and o_status='Not verified'";
 }
 else{
  $sql = "SELECT * FROM organisations where registration like '$name%' and o_zila like '$color%' and o_email like '$email%' and o_number like '$num%' and o_status='Not verified'";
 }

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["o_id"];?></td>
        <td><?php echo $row["registration"];?></td>
        <td><?php echo $row["organisation"];?></td>
        <td><?php echo $row["o_email"];?></td>
        <td><?php echo $row["o_name"];?></td>
        <td><?php echo $row["o_gender"];?></td>
        <td><?php echo $row["o_field"];?></td>
        <td><?php echo $row["o_zila"];?></td>
        <td><?php echo $row["o_address"];?></td>
        <td><?php echo $row["o_number"];?></td>
        <td><a href="verifiedngo.php?id=<?php echo $row['o_id'];?>"><button>Accept</button></a>
        <td><a href="sendrejectngo.php?id=<?php echo $row['o_email'];?>"><button>Reject</button></a>
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
