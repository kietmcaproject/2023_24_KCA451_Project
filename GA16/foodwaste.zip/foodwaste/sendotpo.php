<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include_once('common/connection.php');

include_once('sendmail2.php');


if(isset($_REQUEST['email']))
{
$email =mysqli_real_escape_string($conn,$_POST['email']);
$ranpass =rand(10000,999999);
$check_email = "SELECT * from organisations where o_email='$email' LIMIT 1";
$check_email_run = mysqli_query($conn,$check_email);
if(mysqli_num_rows($check_email_run)>0)
{
    echo "<script>
    window.location.href = 'enteremailo.php';
    alert('Email Exist, Enter different email..');
</script>";
}
else{
$html = "Hii,<br/> Your OTP for verification is {$ranpass}";
sendmail($email,$html,'Forgot Password');
$_SESSION['status']= "we emailed you a password reset link";
header("location: otpo.php?pass=$ranpass & em=$email");
exit(0);
}
}
else{
$_SESSION['status'] = "something went wrong!";
 header("location: enteremail.php");
exit(0);
}
?>