<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:logins.php');
}
 ?>
<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Zero Hunger</title>

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
            <a href="https://www.google.com/maps/dir//Meerut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Meerut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
              <a class="" href="ngohome.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php">Donor Request</a>
              <a class="" href="ngoresetpassword.php">Reset Password</a>
              <a class="" href="ngogallery.php">Gallery</a>
              <a class="" href="ngocontact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="ngohome.php">
            <span>
              Zero Hunger
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
            
            
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section position-relative" >
      <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
          <li data-target="#customCarousel1" data-slide-to="1"></li>
          <li data-target="#customCarousel1" data-slide-to="2"></li>
          <li data-target="#customCarousel1" data-slide-to="3"></li>
        </ol>
        <div class="carousel-inner" style="background-image: url('images/img1.jpeg')">
          <div class="carousel-item active">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                    Take <br />
                    Food
                  </h2>
                </div>
                
              </div>
              <div class="care_detail">
                <a href="ngocontact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                    We will take <br />
                    Care of <br />
                    Hungry Peoples
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Take <br />
                  Food
                  </h2>
                </div>
               
              </div>
              <div class="care_detail">
                <a href="ngocontact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    Hungry Peoples
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Take <br />
                  Food
                  </h2>
                </div>
                
              </div>
              <div class="care_detail">
                <a href="ngocontact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    Hungry Peoples
                  </h2>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="baby_detail">
                <div class="baby_text">
                  <h2>
                  Take <br />
                  Food
                  </h2>
                </div>
               
              </div>
              <div class="care_detail">
                <a href="ngocontact.php">
                  Contact Us
                </a>
                <div class="care_text">
                  <h2>
                  We will take <br />
                    Care of <br />
                    Hungry Peoples
                  </h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- service section -->

  <section class="service_section ">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/grains.png" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                Food
              </h4>
              <p>
               Daily requirement of an Human being,Food is any substance consumed to provide nutritional support and energy to an organism.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box ">
            <div class="img-box">
              <img src="images/images9.png" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                Hungry
              </h4>
              <p>
              There is more than enough food produced in the world to feed everyone. Yet as many as 783 million people still go hungry.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/slogo.webp" alt="" />
            </div>
            <div class="detail-box">
              <h4>
                What is Hunger
              </h4>
              <p>Hunger is interconnected issues of poverty, conflict, climate change and health systems all play a role in driving hunger.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <div class="img-box">
              <img src="images/1234.jpg" alt="" />
            </div>
            <div class="detail-box">
              <h4>
              How to Stop it
              </h4>
              <p>
               By Using our platform we can help Needy people to get Food and clothes Easily. There we support to minimize death from hunger.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end service section -->

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container-fluid">
      <div class="box">
        <div class="img-box">
          <img src="images/img4.jpeg" alt="" />
        </div>
        <div class="detail-box">
          <h2>
            For Accept Food Request!
          </h2>
          <p>
            Here, You can Accept the request to take the food From Donor Destination.
            You can upload details of the Logistics.
          </p>
          <a href="donorrequest.php">
            <span>
              Read More
            </span>
            <hr />
          </a><br/><br/>
          <h2>
            Check Takeaway details of Your Accept request.
          </h2>
          <p>
            Here, we provide the Details of Takeaway Food of that request Which is Already Approved.
          </p>
          <a href="takeaway.php">
            <span>
              Read More
            </span>
            <hr />
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- we have section -->

  <section class="wehave_section">
    <div class="container-fluid">
      <div class="box">
        <div class="detail-box">
          <h2>
            For <br />
            For Accept Clothes Request!
          </h2>
          <p>
          
          <a href="why.php">
            <span>
              Read More
            </span>
            <hr />
          </a>
        </div>
        <div class="img-box">
          <img src="images/img5.webp" alt="" />
        </div>
      </div>
    </div>
  </section>

  <!-- end we have section -->

  <!-- why section -->

    <!-- why section -->

    <section class="why_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Why Choose Us
        </h2>
        <p>
                  </p>
      </div>
      <div class="why_container">
        <div class="box">
          <div class="img-box">
            <img src="images/ch3.jpg" alt="" style="height:80px; width:80px;"/>
          </div>
          <div class="detail-box">
            <h5>
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/ch4.png" alt="" style="height:100px; width:100px;" />
          </div>
          <div class="detail-box">
            <h5>
            
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/ch2.jpg" alt="" />
          </div>
          <div class="detail-box">
            <h5>
            </h5>
            
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/trustlogo.jpg" alt="" />
          </div>
          <div class="detail-box">
            <h5>
            </h5>
            
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end why section -->

  <!-- end why section -->

  <!-- team section -->

  <section class="team_section">
    <div class="container-fluid">
      <div class="heading_container">
       <h2>
          Our Team
        </h2>
        <p>
         Navneet Chaudhary   ||   Madhav Sharma   ||   Nitish Gupta   ||   Peeyush Tyagi
        </p>
      </div>
      <div class="carousel-wrap ">
        <div class="owl-carousel team_carousel">
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/nav2.jpeg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Navneet Chaudhary<br>
                  (Leader)
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/madhav.jpg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Madhav Sharma
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/madhavsharmawd">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/nitish.jpeg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Nitish Gupta
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/peeyush.jpeg" alt="" />
              </div>
              <div class="detail-box">
                <h6>
                  Peeyush Tyagi
                </h6>
                <div class="social_box">
                  <a href="https://m.facebook.com/profile.php/?id=100009018195397">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                  </a>
                  <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                  <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                  </a>
                  <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end team section -->

  <!-- contact section -->

  <section class="contact_section layout_padding-top">
    <div class="container">
      <div class="row">
        <div class="col-md-8 mx-auto">
          <div class="contact-form">
            <div class="heading_container">
              <h2>
                Any Quaries / Suggestion
              </h2>
            </div>
            <form action="ngoquery.php" method="post">
              <input value="<?= $_SESSION['name'];?>"type="text" name="name" placeholder="Full name ">
              <div class="top_input">
                <input value="<?= $_SESSION['email'];?>"type="email" name="email" placeholder="Email">
                <input  type="tel" name="number" placeholder="Phone Number">
              </div>
              <input type="text" name="message" placeholder="Message" class="message_input">
              <div class="btn-box">
                <button type="send" name="send" >Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end contact section -->

  <!-- client section -->

  <section class="client_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Related Information
        </h2>
      </div>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="box">
              <div class="img-box">
                <img src="images/content.webp" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                     Global Hunger Ranking.
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                India ranked 111th out of 125 countries in the Global Hunger Index-2023 with the country reporting the highest child wasting rate at 18.7 per cent. The index was released on Thursday. India ranked 107th out of 121 countries in 2022.
              </p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="img-box">
                <img src="images/feed.jpeg" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                       FEEDING INDIA
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                Severe food insecurity is one extreme of the scale, but even moderate food insecurity is worrisome. For those who are moderately food insecure, access to food is uncertain. They might have to sacrifice other basic needs, just to be able to eat. When they do eat, it might be whatever is most readily available or cheapest, which might not be the most nutritious food. The rise in obesity and other forms of malnutrition is partly a result of this phenomenon.
                </p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="box">
              <div class="img-box">
                <img src="images/lab3.png" alt="" />
              </div>
              <div class="client_detail">
                <div class="client_name">
                  <div class="client_info">
                    <h4>
                    Food Safety and Standards Authority of India
                    </h4>
                    <span>
                      Vision
                    </span>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                The State Food Safety Index (SFSI), was developed in 2018 in collaboration with the FSSAI. The SFSI was created to motivate the States and Union Territories to improve their performance and work towards establishing an appropriate food safety ecosystem.
                </p>
              </div>
            </div>
          </div>
        </div>
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
      </div>
    </div>
  </section>

  <!-- end client section -->

  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Meerut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location: Meerut,Uttar Pradesh(India)
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +91 9759000083
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="https://m.facebook.com/profile.php/?id=100009018195397">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="https://www.linkedin.com/in/navneet-chaudhary-3269ab256">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="https://instagram.com/navneetchaudhary07?igshid=OGQ5ZDc2ODk2ZA==">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="ngohome.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Requests</a>
              <a class="" href="ngogallery.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a>
              <a class="" href="ngoresetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="ngocontact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
          </h5>
          <form action="emailsend.php" method="post">
            <input type="text" name="email" placeholder="Enter Your email" required>
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Navneet Chaudhary</a>
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>

</body>

</html>