
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
  }
  .button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Clothes Delivered Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
<div>
    <input value=''type="text" placeholder="Enter Email" name="name" id="name">
      <input value=''type="location" placeholder="Enter Zila" name="loc" id="loc">
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
      <th>Driver ID</th>
        <th>Driver Image</th>
        <th>D.Name</th>
        <th>D.Number</th>
        <th>Donar Email</th>
        <th>Donate Date</th>
        <th>Bags</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $loc = filter_input(INPUT_POST,'loc', FILTER_SANITIZE_STRING);
 
 $sql = "SELECT * FROM clothedonate, driver where driver.c_id=clothedonate.cl_id and cl_email like '$name%' and cl_zila like '$loc%'";


$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["d_id"];?></td>
        <td> <img src="images/<?php echo $row['d_image'];?>" style="width:100px"></td>
        <td><?php echo $row["d_name"];?></td>
        <td><?php echo $row["d_number"];?></td>
        <td><?php echo $row["cl_email"];?></td>
        <td><?php echo $row["cl_date"];?></td>
        <td><?php echo $row["cl_bags"];?></td>
        <td><?php echo $row["cl_zila"];?></td>
        <td><a href="deletenewpestinfo.php?id=<?php echo $row['id'];?>"><button>Delete</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
