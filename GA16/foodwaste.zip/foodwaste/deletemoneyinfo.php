<?php
include('common/connection.php');


$id = $_REQUEST['id'];

$sql="delete from moneydonate where m_id = ".$id;

mysqli_query($conn,$sql);
header('Location:moneyinfo.php');
?>