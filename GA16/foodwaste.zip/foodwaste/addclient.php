<?php
include('common/connection.php');



	if(isset($_POST['submit'])){

  	  $name = $_POST['name'];
        $username = $_REQUEST['mail'];
        $number = $_POST['number'];
        $address = $_POST['address'];
        $password = $_POST['pswrd'];
        $age = $_POST['age'];
        $status='Not verified';
        $adhaar = $_POST['adhaar'];
        $city = $_POST['city'];

        $img = $_FILES["img"]["name"];
        $temp = $_FILES["img"]["tmp_name"];
        $file = "images/".$img;
 
        $img2 = $_FILES["img2"]["name"];
        $tempname = $_FILES["img2"]["tmp_name"];
        $folder = "images/".$img2;

        $img3 = $_FILES["img3"]["name"];
        $temp_name = $_FILES["img3"]["tmp_name"];
        $filer = "images/".$img3;

        move_uploaded_file($temp, $file);
        move_uploaded_file($tempname, $folder);
        move_uploaded_file($temp_name, $filer);
        $sql="insert into clientlogin(c_name,c_email,c_number,c_age,c_address,c_password,c_status,adhaar,profile,fadhaar,badhaar,c_city) values('".$name."','$username','$number','$age','$address','$password','$status','$adhaar','$img','$img2','$img3','$city')";

       

        if(mysqli_query($conn,$sql)){
            echo "<script>
      window.location.href = 'logins.php';
      alert('new record inserted successfully... Wait 2 hours for verification......')</script>";
            
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>