<?php
include('common/connection.php');



	if(isset($_POST['submit'])){

            $name = $_POST['name'];
              $username = $_REQUEST['mail'];
        $field = $_POST['field'];
        $number = $_POST['number'];
        $pan = $_POST['pan'];
        $gender = $_POST['gender'];
        $organisation = $_POST['organisation'];
        $address = $_POST['address'];
        $password = $_POST['pswrd'];
        $date = $_POST['date'];
        $status='Not verified';
        $zila = $_POST['zila'];
        $sql="insert into organisations(o_name,o_email,o_number,o_address,o_password,organisation,o_field,o_gender,o_status,o_zila,registration) values('".$name."','$username','$number','$address','$password','$organisation','$field','$gender','$status','$zila','$pan')";

       

        if(mysqli_query($conn,$sql)){
            echo "<script>
      window.location.href = 'logins.php';
      alert('new record inserted successfully... Wait 2 hours for verification......')</script>";
            
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>

