<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:logins.php');
}
 ?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Zero Hunger</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
 
 select{
    width: 200%;
    margin: 10px 0;
    border-color: greenyellow;
    border-radius: 5px;
    padding: 7px 10px 7px 0px;
    font-size: 18px; 
    box-sizing: border-box;
    cursor: pointer;
  }
  .navbar-b{
    margin-top: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .dropdown{
    margin-left: 10%;
    background-color: white;
    border-radius: 3px;  
  }
  main{
    padding-top: 20px;
    max-width: 1500px;
    width: 95%;
    margin: 30px auto;
    display: flex;
    flex-wrap: wrap;
    margin: auto;
    margin-bottom: 15px;
  }
  main .card{
    max-width: 250px;
    flex: 1 1 210px;
    text-align: center;
    height: 570px;
    border: 1px solid lightgray;
    margin: 20px;
  }
  main .card .image{
    height: 60%;
    margin-bottom: 20px;
  }
  main .card .image img{
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  main .card .caption{
    padding-left: 1em;
    text-align: left;
    line-height: 3em;
  }
  main .card .caption p{
    font-size: 1em;
  }
  main .card .caption .rate{
    display: flex;
  }
  main .card .caption .rate i{
    color: gold;
    margin-left: 2px;
  }
  main .card a{
    width: 50%;
  }
  main .card a{
    margin-left: 10%;
    border: 2px solid black;
    padding: 0.8em;
    width: 80%;
    cursor: pointer;
    font-weight: bold;
    position: relative;
    margin-bottom:5%;
  }
  main .card button::before{
     content: "";
     position: absolute;
     top: 0;
     left: 0;
     bottom: 0;
     width: 0;
     background-color: yellowgreen;
     transition: all .5s;
     margin: 0; 
     
  }
  main .card button::after{
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    width: 0;
    background-color: yellowgreen;
    transition: all .5s;
  }
  main .card button:hover::before{
      width: 30%;
  }
  main .card button:hover::after{
      width: 30%;
  }
  #showsection .cards{
 		padding-bottom: 20px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 50px;
    position: relative;
    height: 245px;
}
#showsection .cards >div{
    width: 350px;
    background-color: var(--gray);
    padding: 35px;
    color: #444;
    text-align: center;
    border-radius: 15px;
    height: 215px;
    border: 1px solid #ccc;
    transition: 0.4s;
}
#showsection .cards > div:hover{
    width: 400px;
    margin-top: -20px;
    border-color: var(--themeRed);
    padding: 55px;
    height: auto;
}
#showsection .cards > div .title{
    font-size: 18px;
    font-weight: 600;
    text-transform: uppercase;
}

#showsection .cards > div button{
    border: 1px solid var(--themeRed);
    outline: none;
    padding: 7px 15px;
    margin-top: 15px;
    font-size: 12px;
    border-radius: 3px;
    cursor: pointer;
    transition: 0.3s;
    background-color: lightgreen;
}
#showsection .cards > div:hover button {
    background-color: var(--themeRed);
    color: black;
}
.donationbox{
    animation: myanimation 10s infinite;
}
@keyframes myanimation {
  0% {background-image: url('images/money.jpeg');}
  25%{background-image: url('images/money2.jpeg');}
  50%{background-image: url('images/money3.jpeg');}
  75%{background-image: url('images/money.jpeg');}
  100% {background-image: url('images/mobile2.jpeg');}
}
.volunteerBox{
    animation: myanimation2 10s infinite;
}
@keyframes myanimation2 {
  0% {background-image: url('images/food.jpeg');}
  25%{background-image: url('images/food2.jpeg');}
  50%{background-image: url('images/food3.jpeg');}
  75%{background-image: url('images/food.jpeg');}
  100% {background-image: url('images/foed2.jpeg');}
}
.scholarshipBox{
    animation: myanimation3 10s infinite;
}
@keyframes myanimation3 {
  0% {background-image: url('images/clothes3.jpeg');}
  25%{background-image: url('images/clothes.webp');}
  50%{background-image: url('images/clothes2.jpeg');}
  75%{background-image: url('images/clothes3.jpeg');}
  100% {background-image: url('images/foed2.jpeg');}
}
    </style>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
          <a href="https://www.google.com/maps/dir//Merrut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Merrut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
              <a class="" href="home.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donation.php">Donation</a>
              <a class="" href="history.php">History</a>
              <a class="" href="resetpassword.php">Reset Password</a>
              <a class="" href="why.php">Gallery</a>
              <a class="" href="contact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="home.php">
            <span>
              Zero Hunger
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
</div>
<section class="fullcontainer" id="showsection" style="background-image: url('images/back3.jpeg'); margin-top: -15px;">
          <div class="container">
			  <h2 class="sectionTitle" style="text-align: center; padding-top:100px;">DONATE</h2>
             <div class="cards" style="margin-top: 100px; margin-bottom: 50px;">
				 <div class="donationbox">
					 <div class="title">Money Donation Box</div><br><br>
					 <a href="foundpest.php">
					 <button>
						Donate now
					 </button>
					 </a>
				 </div>
				<div class="volunteerBox">
					<div class="title">Food Donation Box</div><br><br>
					<a href="fooddonate.php">
					<button>
						 Donate now
					</button>
					</a>
				</div>
				<div class="scholarshipBox">
					<div class="title">Clothes Donation Box</div><br><br>
					<a href="clothesdonate.php">
					<button>
						Donate Now
					</button>
					</a>
				</div>
			</div>			 
		  </div>
 

  <!-- end why section -->


  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Merrut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="tel:9759000083">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +9759000083
                </span>
              </a>
              <a href="mailto:chaudharynavneet1234@gmail.com">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="home.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donation.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Donation</a>
              <a class="" href="history.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>History</a>
              <a class="" href="why.php"> <i class="fa fa-angle-right" aria-hidden="true"></i>Gallery</a>
              <a class="" href="resetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="contact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
            Newsletter
          </h5>
          <form action="">
            <input type="text" placeholder="Enter Your email" />
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Navneet Chaudhary</a>  <a href="https://themewagon.com"></a>
    </p>
  </footer>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
 
</body>

</html>