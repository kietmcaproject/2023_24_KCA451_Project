<?php
include('common/connection.php');
session_start();
	if(isset($_POST['pswrd'])){

  		$pswrd = $_POST['pswrd'];

         $sql="UPDATE clientlogin SET password='".$pswrd."' WHERE id = ".$_SESSION['id'];

       // / print_r($sql); die();

        if(mysqli_query($conn,$sql)){

            session_start();
session_destroy();
        	echo "<script>
      window.location.href = 'logins.php';
      alert('Reset password successfully...');
      </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>
