
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
    padding-left:1px;
  }
  .button{
    margin-top:2%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Queries Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value=''type="text" placeholder="Name" name="name" id="name">
      <input value=''type="address" placeholder="Email" name="color" id="color">
      <input value=''type="tel" placeholder="Phone Number" name="num" id="num">
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>

        <th>Name</th>

        <th>Email</th>

        <th>Number</th>
        
        <th>Message</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $num = filter_input(INPUT_POST,'num', FILTER_SANITIZE_STRING);
 
  $sql = "SELECT * FROM query where q_email like '$color%' and q_name like '%$name%' and q_number like '$num%'";

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["q_id"];?></td>
        <td><?php echo $row["q_name"];?></td>
        <td><?php echo $row["q_email"];?></td>
        <td><?php echo $row["q_number"];?></td>
        <td><?php echo $row["q_message"];?></td>
        <td><a href="deletequeryinfo.php?id=<?php echo $row['id'];?>"><button>Delete</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
