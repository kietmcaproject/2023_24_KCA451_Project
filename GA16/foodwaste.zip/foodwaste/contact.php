<?php
 include('common/mainheader.php');
 ?>
    <!-- end header section -->
  </div>
<style>
  .contact_section{
    background-color:LightGray;
  }
  </style>

  <!-- contact section -->

  <section class="contact_section layout_padding" style="margin-top:-670px; padding-top:170px;">
    <div class="container">
      <div class="row">
        <div class="col-md-8 mx-auto">
          <div class="contact-form">
            <div class="heading_container">
              <h1>
                CONTACT US
              </h1>
            </div>
            <form action="query.php" method="post">
            <input value="<?= $_SESSION['name'];?>"type="text" placeholder="Full name " name="name"/>
              <div class="top_input">
                <input value="<?= $_SESSION['email'];?>"type="email" placeholder="Email" name="email" />
                <input type="text" placeholder="Phone Number" name="number"/>
              </div>
              <input type="text" placeholder="Message" class="message_input" name="message"/>
              <div class="btn-box">
                <button value='send' type='send' for='send' name="send">
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end contact section -->

  <!-- info section -->
  <?php
 include('common/footer.php');
 ?>
  <!-- footer section -->

  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>

</body>

</html>