<?php
include('common/connection.php');


$id = $_REQUEST['id'];
  		$status = 'Delivered';
        $sql="UPDATE fooddonate SET f_status='$status' WHERE f_id = '$id'";

        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'takeaway.php';
    </script>";
        }
        mysqli_close($conn);

?>