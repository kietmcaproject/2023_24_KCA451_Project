
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
    width:15%;
  }
  select{
    width:8%;
  }
  button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  .container{
    margin-left:2%;
  }
  </style>
  <div class="fnt">
    <h1>Verify Donor</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>

        <th>Name</th>
        <th>Profile Photo</th>
        <th>Age</th>

        <th>Email</th>

        <th>Number</th>
        <th>city</th>
        <th>Adhaar Number</th>
        <th>Address</th>
        <th>Adhaar Front Photo</th>
        <th>Adhaar Back Photo</th>
      </tr>
    </thead>
    <tbody>

    <?php
 
  $sql = "SELECT * FROM clientlogin where c_status='Not verified'" ;


$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["c_id"];?></td>
        <td><?php echo $row["c_name"];?></td>
        <td> <img src="images/<?php echo $row['profile'];?>" style="width:100px"></td>
        <td><?php echo $row["c_age"];?></td>
        <td><?php echo $row["c_email"];?></td>
        <td><?php echo $row["c_number"];?></td>
        <td><?php echo $row["c_city"];?></td>
        <td><?php echo $row["adhaar"];?></td>
        <td><?php echo $row["c_address"];?></td>
        <td> <img src="images/<?php echo $row['fadhaar'];?>" style="width:100px"></td>
        <td> <img src="images/<?php echo $row['badhaar'];?>" style="width:100px"></td>
        <td><a href="verifieduser.php?id=<?php echo $row['c_id'];?>"><button>Accept</button></a>
        <td><a href="sendreject.php?id=<?php echo $row['c_email'];?>"><button>Reject</button></a>
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
