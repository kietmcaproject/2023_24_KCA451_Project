<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include_once('common/connection.php');

include_once('sendmail2.php');


if(isset($_REQUEST['id']))
{
$email =$_REQUEST['id'];
$html = "Hii,<br/> Your Account will not verify due to some wrong information<br/>Signup again with right information";
sendmail($email,$html,'OTP');
$_SESSION['status']= "we emailed you a password reset link";
header("location: deleteuserngo.php?em=$email");
exit(0);
}
else{
$_SESSION['status'] = "something went wrong!";
 header("location: verifyngo.php");
exit(0);
}
?>