<?php
include('common/connection.php');


$id = $_REQUEST['em'];

$sql="delete from organisations where o_email ='$id'";
mysqli_query($conn,$sql);
header("Location:verifyngo.php");
?>