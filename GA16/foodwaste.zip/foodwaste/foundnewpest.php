<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $email = $_POST['email'];
        $date = $_POST['date'];
        $upi_id = $_POST['upi_id'];
        $reference = $_POST['reference'];
         $status='Not verified';
          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;

        move_uploaded_file($tempname, $folder);
        $sql="insert into moneydonate(m_name,m_image,m_email,m_date,upi_id,reference,m_status) values('".$name."','$img','$email','$date','$upi_id','$reference','$status')";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'moneydonatehistory.php';
          alert('your record inserted..');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>