<?php
 
include('common/connection.php');
 // print_r($_POST);die();
if(isset($_POST['submit'])){
     $otp = $_REQUEST['pass'];
     $mail=$_REQUEST['em'];
     $cust=$_POST['otp'];
       if($otp==$cust)
       {
        echo "<script>
        window.location.href = 'register.php?em=$mail';
        alert('Successfully...');
    </script>";
       }
       else{
      
        echo "<script>
      window.location.href = 'enteremail.php';
      alert('you Enter wrong otp...');
  </script>";
     }
    }

    else{
      
      echo "<script>
    window.location.href = 'otp.php';
    alert('you Enter wrong otp...');
</script>";
   }

?>