<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $type = $_POST['type'];
        $symptoms = $_POST['symptoms'];
        $bionomics = $_POST['bionomics'];
        $solution = $_POST['solution'];

          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;

        move_uploaded_file($tempname, $folder);
        $sql="insert into pests(name,image,type,symptoms,bionomics,solution) values('".$name."','$img','$type','$symptoms','$bionomics','$solution')";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'uploadpests.php';
          alert('upload details successfully...');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>