<?php
include('common/connection.php');

	if(isset($_POST['submit'])){

  		$name = $_POST['name'];
        $email = $_POST['email'];
        $zila = $_POST['zila'];
        $packets = $_POST['packets'];
        $type_name = $_POST['type_name'];
        $address = $_POST['address'];
        $date = $_POST['date'];
         $status='Not verified';
          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;

        move_uploaded_file($tempname, $folder);
        $sql="insert into fooddonate(f_name,f_image,f_email,f_packets,f_type_name,f_address,f_status,f_date,f_zila) values('".$name."','$img','$email','$packets','$type_name','$address','$status','$date','$zila')";


        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'fooddonationhistory.php';
          alert('your record inserted..');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>