<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:ngologin.php');
}
$id = $_REQUEST['id'];
 ?>
<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Zero Hunger</title>

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
            <a href="https://www.google.com/maps/dir//Meerut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Meerut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
            <a class="" href="ngohome.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="donorrequest.php">Donor Request</a>
              <a class="" href="ngoresetpassword.php">Reset Password</a>
              <a class="" href="ngogallery.php">Gallery</a>
              <a class="" href="ngocontact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="home.php">
            <span>
              Zero Hunger
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
            
            
          </div>
        </nav>
      </div>
    </header>
<style>
  <style>
@media screen and (max-width: 600px) {
  form{
    width: 25rem;
  }

}

@media screen and (max-width: 400px) {
  form{
    width: 20rem;
  }
}
body 
{
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  
}

h1{
    text-align: center;
}


.form-p{
    width:35rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
    margin-bottom:20px;
}
.select-p{
  font-size:30px;
}

input[type=file],input[type=text], input[type=name],input[type=email]{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 10px 18px;
    box-sizing: border-box;
  }
  select{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 15px 20px;
    box-sizing: border-box;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 5px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }

  /* Media queries for the responsiveness of the page */
  @media screen and (max-width: 600px) {
    form{
      width: 25rem;
    }
  }
  
  @media screen and (max-width: 400px) {
    form{
      width: 20rem;
    }
  }

  /* image logo */
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}
.col-md-4{
  width:10px;
}
  </style>
</style>
    <form action="driverconnectiontwo.php?id=<?php echo $row['id'];?>" method="post" enctype="multipart/form-data" style="margin-top: 30px;" class="form-p">
    <div class="imgcontainer">
    
    <img src="images/logo1.jpg" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Driver Details</h3>
            <p><?= $_SESSION['email'];?></p>
            <p>NOTE: Enter Details</p>
        </div>
        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Password -->
            <label for="text">Organisation Email</label>
            <input type="email" value="<?= $_SESSION['email'];?>" placeholder="Enter Organisation Email" name="o_email" required>
            <label for="text">Name</label>
            <input type="text" placeholder="Enter Driver Name" name="name" required>
            <label for="image">Driver Photo</label>
            <input type="file" placeholder="upload image" required class="img" name="img">
            <label for="text">Date-Time for Pickup</label><br>
            <input type="datetime-local" placeholder="Date" required class="date" name="date"><br><br>
            <label for="text">Vechile Number</label>
            <input type="text" placeholder="Enter vechile Number" name="vechile" required>
            <label for="text">Mobile Number</label>
            <input type="text" placeholder="Enter Mobile Number" name="number" required>
            <label for="text">Clothes Information Id</label>
            <input type="text" value="<?php echo $id ?>" name="c_id" required>
            <!-- Submit button -->
            <button type="submit" name="submit">send</button>

            <p class="register">History-><a href="ngohistory.php"></a></p>
            <p class="register">Go Back-><a href="donorrequest.php">Donor Request</a></p>

        </div>

    </form>
    <?php
include('common/footer.php');
?>
    <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
  </body>
</html>