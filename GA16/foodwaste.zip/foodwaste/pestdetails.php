<?php 

include('common/connection.php');
  session_start();

if(!isset($_SESSION['id']) || $_SESSION['id']=='')
{
 header('Location:logins.php');
}
 ?>
<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Pests</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- fonts awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,500,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <script
			src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"
			integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg=="
			crossorigin="anonymous"
			referrerpolicy="no-referrer"
		></script>
  <style>
    .hedding {
    font-size: 20px;
    color: #ab8181`;
}

.main-sectione {
    left: 50%;
    right: 50%;
    transform: translate(-50%, 5%);
    margin-bottom:10%;
}

.left-side-product-box img {
    width: 100%;
}

.left-side-product-box .sub-img img {
    margin-top: 5px;
    width: 83px;
    height: 100px;
}

.right-side-pro-detail span {
    font-size: 15px;
}

.right-side-pro-detail p {
    font-size: 25px;
    color: #a1a1a1;
}

.right-side-pro-detail .price-pro {
    color: #E45641;
}

.right-side-pro-detail .tag-section {
    font-size: 18px;
    color: #5D4C46;
}

.pro-box-section .pro-box img {
    width: 100%;
    height: 200px;
}

@media (min-width:360px) and (max-width:640px) {
    .pro-box-section .pro-box img {
        height: auto;
    }
}
#download-button{
  margin:4%;
  float:right;

}
#download-button:hover{
  background-color:lightgreen;
}
    </style>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="contact_nav_container">
        <div class="container">
          <div class="contact_nav">
          <a href="https://www.google.com/maps/dir//Merrut">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Address : Merrut, Uttar Pradesh(INDIA)
              </span>
            </a>
            <a href="mailto:chaudharynavneet1234@gmail.com">
              <i class="fa fa-envelope" aria-hidden="true"></i>
              <span>
                Email : chaudharynavneet1234@gmail.com
              </span>
            </a>
            <a href="tel:9759000083">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Phone Call : +91 9759000083
              </span>
            </a>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
          </div>
          <div id="myNav" class="overlay">
            <div class="menu_btn-style ">
              <button onclick="closeNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div class="overlay-content">
              <a class="" href="home.php"> Home <span class="sr-only">(current)</span></a>
              <a class="" href="governmentschemes.php">Government Schemes (सरकारी योजनाए) </a>
              <a class="" href="why.php">Crops and pests (फसलें और कीट)</a>
              <a class="" href="foundpest.php">Found New pests (नया कीट मिला)</a>
              <a class="" href="resetpassword.php"> Reset Password (पासवर्ड रीसेट)</a>
              <a class="" href="contact.php"> Contact Us</a>
            </div>
          </div>
          <a class="navbar-brand" href="home.php">
            <span>
              Anti Pesto
            </span>
          </a>
          <div class="user_option">
          <i class="fa fa-user" aria-hidden="true"></i>
          <a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['name'];?></a>
          <a href="logout.php">
              <span>
                Logout
              </span>
            </a>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>
  <button id="download-button" >Download Pdf</button>
<div class="container-b">
    <div class="col-lg-8 border p-3 main-sectione bg-white" id="pdf">
        <div class="row hedding m-0 pl-3 pt-0 pb-3" >
            Pests Details
        </div>
        <?php
$sql = "SELECT * FROM pests where id =".$_REQUEST['id'];
$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>
        <div class="row m-0">
            <div class="col-lg-4 left-side-product-box pb-3">
                <img src="images/<?php echo $row['image'];?>" class="border p-3">
            </div>
            <div class="col-lg-8">
                <div class="right-side-pro-detail border p-3 m-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <span>Name</span>
                            <p class="m-0 p-0"><?php echo $row["name"];?></p>
                            <span>Type</span>
                            <p class="m-0 p-0"><?php echo $row["type"];?></p>
                        </div>
                        <div class="col-lg-12">
                            <p class="m-0 p-0 price-pro"></p>
                            <hr class="p-0 m-0">
                        </div>
                        <div class="col-lg-12 pt-2">
                            <h5>Symptoms</h5>
                            <span><?php echo $row["symptoms"];?></span>
                            <hr class="m-0 pt-2 mt-2">
                        </div>
                        <div class="col-lg-12 pt-2">
                            <h5>Bionomics</h5>
                            <span><?php echo $row["Bionomics"];?></span>
                            <hr class="m-0 pt-2 mt-2">
                        </div>
                        <div class="col-lg-12 pt-2">
                            <h5>Solution</h5>
                            <span><?php echo $row["solution"];?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } } ?>
</div>
<script>
			const button = document.getElementById('download-button');

			function generatePDF() {
				// Choose the element that your content will be rendered to.
				const element = document.getElementById('pdf');
				// Choose the element and save the PDF for your user.
				html2pdf().from(element).save();
			}

			button.addEventListener('click', generatePDF);
		</script>
 <script src="html2pdf.bundle.min.js"></script>
  <!-- why section -->


  <!-- end why section -->


  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="info_contact">
            <h5>
              Address
            </h5>
            <div class="contact_link_box">
              <a href="https://www.google.com/maps/dir//Merrut">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="tel:9759000083">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +9759000083
                </span>
              </a>
              <a href="mailto:chaudharynavneet1234@gmail.com">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  chaudharynavneet1234@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="info_link_box">
            <h5>
              Navigation
            </h5>
            <div class="info_links">
              <a class="" href="home.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Home <span class="sr-only">(current)</span></a>
              <a class="" href="governmentschemes.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Government Schemes</a>
              <a class="" href="why.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Crops and pests </a>
              <a class="" href="foundpest.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Found New Pests</a>
              <a class="" href="resetpassword.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Reset Pasword</a>
              <a class="" href="contact.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Contact Us</a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <h5>
            Newsletter
          </h5>
          <form action="">
            <input type="text" placeholder="Enter Your email" />
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="footer_section container-fluid">
    <p>
      &copy; <span id="displayYear"></span> All Rights Reserved. Design by
      <a href="https://html.design/">Anti Pesto</a>  <a href="https://themewagon.com"></a>
    </p>
  </footer>
  <!-- footer section -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="js/custom.js"></script>
  
</body>

</html>