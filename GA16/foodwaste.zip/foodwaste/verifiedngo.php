
<?php
include('common/connection.php');


$id = $_REQUEST['id'];
  		$status = 'verified';
        $sql="UPDATE organisations SET o_status='$status' WHERE o_id = '$id'";

        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'verifyngo.php';
    </script>";
        }
        mysqli_close($conn);

?>