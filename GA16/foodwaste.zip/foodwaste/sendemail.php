<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo 6; die();
include_once('common/connection.php');

include_once('sendmail.php');
print_r($_REQUEST); die();

if(isset($_REQUEST['email']))
{
  $email =mysqli_real_escape_string($con,$_POST['email']);
  $token = md5(rand());

  $check_email = "SELECT email from clientlogin where email='$email' LIMIT 1";
  $check_email_run = mysqli_query($con,$check_email);

  if(mysqli_num_rows($check_email_run)>0)
  {
        $row=mysqli_fetch_array($check_email_run);
        $get_name = $row['name'];
        $get_email = $row['email'];
        $update_tocken = "UPDATE clientlogin set tocken='$tocken' where email='$get_email'";
        $update_tocken_run = mysqli_query($con,$update_tocken);

        if($update_tocken_run)
        {
          $html = 'Click here to reset password <a href="http://localhost/antipesto/resetpassword.php?token='.$tocken.'">Reset Password</a>':
          sendmail($get_email,$get_name,$html,'Forgot Password');
              $_SESSION['status']= "we emailed you a password reset link";
              header("location: logins.php");
              exit(0);
        }
        else{
            $_SESSION['status'] = "something went wrong!";
             header("location: forget.php");
             exit(0);
        }
  }
  else{
    $_SESSION['status'] = "NO Email found";
    header("location: forget.php");
    exit(0);
  }
}
?>