
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
  }
  .button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Upload Schemes Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <label>ID</label>
    <input type="number" placeholder="Enter ID" name="ide" id="ide">
     <label style="margin-left:7%;">From</label>
    <input type="date" placeholder="Enter Name" name="name" id="name">
    <label style="padding-left:2%;">Upto</label>
    <input type="date" placeholder="Enter Crop" name="color" id="color">
    
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
      <th>ID</th>
        <th>TITLE</th>

        <th>PUBLISH DATE</th>

        <th>File Name</th>
      </tr>
    </thead>
    <tbody>
    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $ide = filter_input(INPUT_POST,'ide', FILTER_SANITIZE_STRING);
 if($ide=='')
 {
  if($color == '' && $name=='' )
 {
  $sql = "SELECT * FROM schemes";
 }
 else if($name=='')
 {
  $sql = "SELECT * FROM schemes where date < '$color'";
 }
 else if($color=='')
 {
  $sql = "SELECT * FROM schemes where date >= '$name'";
 }
  else {
  $sql = "SELECT * FROM schemes where date between '$color' and  '$name'";
 }
 }
 else{
 
  $sql = "SELECT * FROM schemes where id='$ide'";

}

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>
      <tr>
      <td><?php echo $row["id"];?></td>
        <td><?php echo $row["title"];?></td>
        <td><?php echo $row["date"];?></td>
        <td><?php echo $row["file"];?></td>
        <td><a href="deleteschemeinfo.php?id=<?php echo $row['id'];?>"><button>Delete</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
