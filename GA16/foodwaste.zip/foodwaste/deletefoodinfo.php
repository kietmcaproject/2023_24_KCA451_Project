<?php
include('common/connection.php');


$id = $_REQUEST['id'];

$sql="delete from fooddonate where f_id = ".$id;

mysqli_query($conn,$sql);
header('Location:foodinfo.php');
?>