<?php
 
include('common/connection.php');
 // print_r($_POST);die();
if(isset($_POST['submit'])){
     $type = $_POST['type'];
  if($type=="101"){
     $sql ="select * from clientlogin where c_status='verified' && c_email='".$_POST['username']."' && c_password='".$_POST['pswrd']."'";

   
     $result =mysqli_query($conn,$sql);

     if(mysqli_num_rows($result) > 0){

         while($row = $result->fetch_assoc()) {

 
       session_start();
         $_SESSION['id'] = $row['c_id'];
          $_SESSION['name'] = $row['c_name'];
          $_SESSION['email'] = $row['c_email'];
        header('Location:home.php');
      
 
       }
     }
     else{
        echo "<script>
      window.location.href = 'logins.php';
      alert('you are not a User...or if applied wait for verify your account..');
      </script>";
     }
    }
  elseif($type=="102"){
      $sql ="select * from organisations where o_status='verified' &&  o_email='".$_POST['username']."' && o_password='".$_POST['pswrd']."'";

   
     $result =mysqli_query($conn,$sql);

     if(mysqli_num_rows($result) > 0){

         while($row = $result->fetch_assoc()) {

 
       session_start();
         $_SESSION['id'] = $row['o_id'];
          $_SESSION['name'] = $row['o_name'];
          $_SESSION['email'] = $row['o_email'];
        header('Location:ngohome.php');
      

    }
     }
     else{
        echo "<script>
      window.location.href = 'logins.php';
      alert('you are not a User...or if applied wait for verify your account..');
     </script>";
     }
    }
  elseif($type=="103"){
      $sql ="select * from admin where a_email='".$_POST['username']."' && a_password='".$_POST['pswrd']."'";

   
     $result =mysqli_query($conn,$sql);

     if(mysqli_num_rows($result) > 0){

         while($row = $result->fetch_assoc()) {

 
       session_start();
         $_SESSION['id'] = $row['a_id'];
          $_SESSION['name'] = $row['a_name'];
          $_SESSION['email'] = $row['a_email'];
        header('Location:admindetails.php');
      

    }
     }
     else{
      
        echo "<script>
      window.location.href = 'logins.php';
      alert('you are not a admin...');
</script>";
     }
    }
    else{
      
      echo "<script>
    window.location.href = 'logins.php';
    alert('you are not a member of our Organisations...');
</script>";
   }
}

?>