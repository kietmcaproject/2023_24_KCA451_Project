
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
    width:15%;
  }
  select{
    width:8%;
  }
  button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  .container{
    margin-left:5%;
  }
  </style>
  <div class="fnt">
    <h1>Donor Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value='' type="name" placeholder=" Name" name="name" id="name">
      <input value='' type="address" placeholder=" Zila" name="color" id="color">
      <input value='' type="text" placeholder=" Email" name="email" id="email">
      <input value='' type="tel" placeholder=" Number" name="num" id="num" >
      <input value='' type="age" placeholder=" Age" name="age" id="age" >
      <select name="type" id="type">
        <option value="=">= (equal)</option>
        <option value=">"> >(greater than)</option>
        <option value="<">< (less than)</option>
        <option value=">=" selected>>= (greater than equals to)</option>
        </select>
    </div>
    <div class="button-b">
        <button type="submit">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Profile</th>
        <th>Name</th>

        <th>Age</th>

        <th>Email</th>

        <th>Number</th>
        
        <th>Address</th>
        <th>Zila</th>
        <th>Adhaar Number</th>
        <th>Front Adhaar Photo</th>
        <th>Back Adhaar Photo</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $email = filter_input(INPUT_POST,'email', FILTER_SANITIZE_STRING);
 $age = filter_input(INPUT_POST,'age', FILTER_SANITIZE_STRING);
 $type = filter_input(INPUT_POST,'type', FILTER_SANITIZE_STRING);
 $num = filter_input(INPUT_POST,'num', FILTER_SANITIZE_STRING);
 
 if($type=='')
 {
  $sql = "SELECT * FROM clientlogin where c_status='verified' and c_name like '$name%' and c_city like '$color%' and c_email like '$email%' and c_age >= 0 and c_number like '$num%'" ;
 }
 else{
  $sql = "SELECT * FROM clientlogin where c_status='verified' and c_name like '$name%' and c_city like '$color%' and c_email like '$email%' and c_age $type '$age' and c_number like '$num%'" ;
 }

$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["c_id"];?></td>
      <td> <img src="images/<?php echo $row['profile'];?>" style="width:100px"></td>
        <td><?php echo $row["c_name"];?></td>
        <td><?php echo $row["c_age"];?></td>
        <td><?php echo $row["c_email"];?></td>
        <td><?php echo $row["c_number"];?></td>
        <td><?php echo $row["c_address"];?></td>
        <td><?php echo $row["c_city"];?></td>
        <td><?php echo $row["adhaar"];?></td>
        <td> <img src="images/<?php echo $row['fadhaar'];?>" style="width:100px"></td>
        <td> <img src="images/<?php echo $row['badhaar'];?>" style="width:100px"></td>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
