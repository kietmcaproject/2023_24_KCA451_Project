<?php
include('common/connection.php');
	if(isset($_POST['submit'])){
        $o_email= $_REQUEST['o_email'];
        $id= $_REQUEST['f_id'];
  		$name = $_POST['name'];
        $date = $_POST['date'];
        $vechile = $_POST['vechile'];
        $number = $_POST['number'];
          $img = $_FILES["img"]["name"];
        $tempname = $_FILES["img"]["tmp_name"];
        $folder = "images/".$img;
        
        move_uploaded_file($tempname, $folder);
        $sql="insert into driver(d_name,d_image,d_date,d_vechile,d_number,f_id,o_email) values('".$name."','$img','$date','$vechile','$number','$id','$o_email')";
  	
        if(mysqli_query($conn,$sql)){
          echo "<script>
          window.location.href = 'delivered.php?id=$id';
          alert('your record inserted..');
    </script>";
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}

?>