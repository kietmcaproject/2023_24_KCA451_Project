
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
  }
  .button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Clothes Donation Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value=''type="text" placeholder="Enter Email" name="name" id="name">
      <input value=''type="address" placeholder="Enter Zila" name="color" id="color">
      <input value=''type="location" placeholder="Enter Phone" name="loc" id="loc">
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
      <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>Address</th>
        <th>Zila</th>
        <th>packets</th>
        <th>Date</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $loc = filter_input(INPUT_POST,'loc', FILTER_SANITIZE_STRING);
 
  $sql = "SELECT * FROM clothedonate, clientlogin where clothedonate.cl_email=clientlogin.c_email and clothedonate.cl_email like '$name%' and clothedonate.cl_zila like '$color%' and clientlogin.c_number like '$loc%' order by cl_date desc";


$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["cl_id"];?></td>
        <td> <img src="images/<?php echo $row['cl_image'];?>" style="width:100px"></td>
        <td><?php echo $row["c_name"];?></td>
        <td><?php echo $row["c_email"];?></td>
        <td><?php echo $row["c_number"];?></td>
        <td><?php echo $row["cl_address"];?></td>
        <td><?php echo $row["cl_zila"];?></td>
        <td><?php echo $row["cl_bags"];?></td>
        <td><?php echo $row["cl_date"];?></td>
        <td><?php echo $row["cl_status"];?></td>
        <td><a href="deletenewpestinfo.php?id=<?php echo $row['id'];?>"><button>Delete</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
