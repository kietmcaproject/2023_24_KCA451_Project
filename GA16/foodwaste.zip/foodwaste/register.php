<!DOCTYPE html>
<html>
  <head>
  <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page in HTML</title>
    <style>
@media screen and (max-width: 600px) {
  form{
    width: 25rem;
  }

}

@media screen and (max-width: 400px) {
  form{
    width: 20rem;
  }
}
body 
{
  font-family:sans-serif; 
  background: -webkit-linear-gradient(to right, #155799, #159957);  
  background: linear-gradient(to right, #155799, #159957); 
  color:whitesmoke;
}

h1{
    text-align: center;
}


form{
    width:35rem;
    margin: auto;
    color:whitesmoke;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(11, 15, 13, 0.582);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.125);
    padding: 20px 25px;
}

input[type=file],input[type=text], input[type=password],input[type=tel],input[type=number]{
    width: 100%;
    margin: 10px 0;
    border-radius: 5px;
    padding: 15px 18px;
    box-sizing: border-box;
  }
  input[type=file]{
    font-size: 18px;
  }

button {
    background-color: #030804;
    color: white;
    padding: 14px 20px;
    border-radius: 5px;
    margin: 7px 0;
    width: 100%;
    font-size: 18px;
  }

button:hover {
    opacity: 0.6;
    cursor: pointer;
}

.headingsContainer{
    text-align: center;
}

.headingsContainer p{
    color: gray;
}
.mainContainer{
    padding: 16px;
}


.subcontainer{
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}

.subcontainer a{
    font-size: 16px;
    margin-bottom: 12px;
}

span.forgotpsd a {
    float: right;
    color: whitesmoke;
    padding-top: 16px;
  }

.forgotpsd a{
    color: rgb(74, 146, 235);
  }
  
.forgotpsd a:link{
    text-decoration: none;
  }

  .register{
    color: white;
    text-align: center;
  }
  
  .register a{
    color: rgb(74, 146, 235);
  }
  
  .register a:link{
    text-decoration: none;
  }

  /* Media queries for the responsiveness of the page */
  @media screen and (max-width: 600px) {
    form{
      width: 25rem;
    }
  }
  
  @media screen and (max-width: 400px) {
    form{
      width: 20rem;
    }
  }
  /* image logo */
  .imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

  </style>
  </head>
  <body>
    <form action="addclient.php?mail=<?php echo $_REQUEST['em'];?>" method="post" enctype="multipart/form-data" style="margin-top: 30px;">

  <div class="imgcontainer">
    <img src="images/logo1.jpg" alt="Avatar" class="avatar" width="100px" height="100px" style="border-radius: 50px;">
  </div>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>REGISTER HERE</h3>
            <p><?= $_REQUEST['em'];?></p>
            <p></p>
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Username -->
            <br>
            <label for="name">Name</label>
            <input type="text" placeholder="Enter Name" name="name" required>
            <br>
            <label for="age">AGE</label>
            <input type="number" placeholder="Enter Age" name="age" required>
            <br>
            <label for="number">Phone Number</label>
            <input type="tel" placeholder="Enter Phone Number" name="number" required>
            <br>
            <label for="address">City</label>
            <input type="text" placeholder="Enter City" name="city" required>
            <br>
            <label for="address">Address</label>
            <input type="text" placeholder="Enter Address" name="address" required>
            
            <br>
            <label for="pswrd">Password</label>
            <input type="password" placeholder="Enter Password" name="pswrd" required>
            <br>
            <label for="image">Upload Profile Picture</label>
            <input type="file" placeholder="Upload Photo" required class="img" name="img" required>
            <br>
            <label for="image">Upload Adhaar Front </label>
            <input type="file" placeholder="Upload Photo" required class="img" name="img2" required>
            <br>
            <label for="image">Upload Adhaar Back</label>
            <input type="file" placeholder="Upload photo" required class="img" name="img3" required>
            <br>
            <label for="pswrd">Adhaar Number</label>
            <input type="tel" placeholder="Enter Adhaar" required class="img"name="adhaar" required>
            
            <!-- sub container for the checkbox and forgot password link -->
            <div class="subcontainer">
                <label>
                  <input type="checkbox" checked="checked" name="remember"> Remember me
                </label>
            </div>


            <!-- Submit button -->
            <button type="submit" name="submit">Register</button>

            <!-- Sign up link -->
            <p class="register">already a member?  <a href="logins.php">login here!</a></p>

        </div>

    </form>

</body>
</html>