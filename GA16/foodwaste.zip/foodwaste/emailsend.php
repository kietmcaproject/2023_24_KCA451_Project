<?php
include('common/connection.php');



	if(isset($_POST['email'])){

  		$email = $_POST['email'];
        $sql="insert into emails(email) values('$email')";

       

        if(mysqli_query($conn,$sql)){
            echo "<script>
            window.location.href = 'home.php';
            alert('your email inserted successfully..');
      </script>";
            
        }
        else{
        	echo "error:" .mysqli_error($conn);
        }
        mysqli_close($conn);
  	}
?>