
<?php 
include('common/header.php');
?>
<style>
  .navbar-b{
    margin-left:6%;
  }
  input{
    border-color:black;
    border-radius:7px;
  }
  .button{
    margin-top:1%;
    background-color:black;
    color:white;
    border-radius:15px;
  }
  .fnt{
    text-align:center;
    color:white;
    padding:0.3%;
    background-color:grey;
    margin-bottom:6%;
    margin-top:-22px;
  }
  </style>
  <div class="fnt">
    <h1>Money Donation Information</h1>
</div>
<div class="navbar-b">
          <div class="dropdown">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">
    <div>
    <input value=''type="text" placeholder="Enter Email" name="name" id="name">
      <input value=''type="address" placeholder="Enter Reference ID" name="color" id="color">
      <input value=''type="location" placeholder="Enter Zila" name="loc" id="loc">
    </div>
    <div class="button-b">
        <button type="submit" class="button">Select</button>
    </div>
</form>
</div>
</div>
<div class="container">
     
  <table class="table">
    <thead>
      <tr>
      <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>Address</th>
        <th>Date</th>
        <th>Reference ID</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>

    <?php
 $color = filter_input(INPUT_POST,'color', FILTER_SANITIZE_STRING);
 $name = filter_input(INPUT_POST,'name', FILTER_SANITIZE_STRING);
 $loc = filter_input(INPUT_POST,'loc', FILTER_SANITIZE_STRING);

  $sql = "SELECT * FROM moneydonate, clientlogin where moneydonate.m_email=clientlogin.c_email and m_status like 'N%' and m_email like '$name%' and c_city like '$loc%' and reference like '$color%'";



$result = $conn->query($sql);



if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


?>


      <tr>
      <td><?php echo $row["m_id"];?></td>
        <td> <img src="images/<?php echo $row['m_image'];?>" style="width:100px"></td>
        <td><?php echo $row["c_name"];?></td>
        <td><?php echo $row["c_email"];?></td>
        <td><?php echo $row["c_number"];?></td>
        <td><?php echo $row["c_city"];?></td>
        <td><?php echo $row["m_date"];?></td>
        <td><?php echo $row["reference"];?></td>
        <td><?php echo $row["m_status"];?></td>
        <td><a href="verifiedmoneyinfo.php?id=<?php echo $row['m_id'];?>"><button>Verified</button></a>
        <td><a href="deletemoneyinfo.php?id=<?php echo $row['m_id'];?>"><button>Delete</button></a>
      </td>
       
      </tr>
     <?php } } ?>
    </tbody>
  </table>
</div>

</body>
</html>
