

<footer id="contactus" style="background-color: #272727;">
    <div class="container" style="width: 100%;">
				<div class="row justify-content-center">
					<div class="col text-center">
                        <img src="img/ftrlg.svg" style="width:60px;" alt="">
                        <h2 class="footer-heading"> 
                        <a href="index.php" style="color: #ffffff; font-family: 'Sora', sans-serif; font-size: 50px; text-decoration: none;"> Jobvio.in </a> 
                        </h2>
                    </div>	
                                                
                    <div class="menu text-center">
                    <p>
                    <a href="index.php" style="color: #ffd6a5; padding-top: 50px; padding-right: 40px; font-family:Comfortaa;"> HOME </a> 
                    <a href="#jbs" style="color: #ffd6a5; padding-top: 50px; padding-right: 40px; font-family:Comfortaa;"> JOBS </a> 
                    <a href="mailto: rakshith.19cs121@sode-edu.in" style="color: #ffd6a5; padding-top: 50px; font-family:Comfortaa;"> CONTACT </a>
                    </p>
                    </div>
					
				</div>
				
                <div class="row mt-5">
					<div class="col-md-12 text-center">
						<p class="copyrigt">
                        <a style="color: #9FA4A9; text-decoration: none;"> All rights reserved 2022 | Developped by </a> 
                        <a href="" style="color: #FDFFAC;">MCA 2022 student, BIT Meerut</a> 
                        <a style="color: #FDFFAC; text-decoration: none;">&</a> 
                        <a href="" style="color: #FDFFAC;">bit</a> 
					    </p>
					</div>
				</div>
    </div>
</footer>